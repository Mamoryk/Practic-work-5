﻿List<IHello> Hi = new List<IHello>();
Hi.Add(new Rus());
Hi.Add(new Eng());
Hi.Add(new Itl());
Hi.Add(new Dtch());
Hi.Add(new Turk());
foreach (IHello lang in Hi)
{
    lang.SayHello();
}
Console.ReadKey(true);
interface IHello
{
    void SayHello();
}

class Rus : IHello { public void SayHello() { Console.WriteLine("Привет!"); } }
class Eng : IHello { public void SayHello() { Console.WriteLine("Hello!"); } }
class Itl : IHello { public void SayHello() { Console.WriteLine("Ciao!"); } }
class Dtch : IHello { public void SayHello() { Console.WriteLine("Hallo!"); } }
class Turk : IHello { public void SayHello() { Console.WriteLine("Selam!"); } }