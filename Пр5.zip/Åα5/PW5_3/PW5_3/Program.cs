﻿using System.Text.RegularExpressions;

Console.Write("Enter the text : ");
#pragma warning disable CS8600 
string textLine = Convert.ToString(value: Console.ReadLine());
#pragma warning restore CS8600 
Console.WriteLine("Choose your filter:1-digit, 2-letter ");
int f = Convert.ToInt32(Console.ReadLine());


Oper(textLine, f);


Console.WriteLine(textLine);
Console.ReadKey(true);
static string Oper(string textLine, int methN)
{
    DigitFilter Dig = new DigitFilter();
    LetterFilter Let = new LetterFilter();
    if (methN == 1) { textLine = Dig.Execute(textLine); }
    else { textLine = Let.Execute(textLine); }
    return textLine;
}

interface IFilter
{
    string Execute(string textLine);
}

class DigitFilter : IFilter
{
    public string Execute(string textLine)
    {
        return textLine = Regex.Replace(textLine, "[0-9]", "", RegexOptions.IgnoreCase);
    }
}

class LetterFilter : IFilter
{
    public string Execute(string textLine)
    {
        
        
        return textLine;
    }
}